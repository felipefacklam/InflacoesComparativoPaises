#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

#include "func.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#endif