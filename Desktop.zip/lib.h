#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

#include "func.h"

#endif