#ifndef FUNC_H_INCLUDED
#define FUNC_H_INCLUDED

void opcaoPais_1(int opcao);

void opcaoPais_2(int opcao);

float diferencaPorTri(float *vet, float *vet_2, int tamanho);

void opcaoComparar(int opcao);

void calcAcum(float *vet, float *vet_2, int tamanho);

#endif